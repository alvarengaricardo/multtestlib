# multtestlib

**multtestlib** is a library for running unit tests using processing parallel, written in Python.



![image-20230301234134049](C:\Users\Ricardo\AppData\Roaming\Typora\typora-user-images\image-20230301234134049.png)

